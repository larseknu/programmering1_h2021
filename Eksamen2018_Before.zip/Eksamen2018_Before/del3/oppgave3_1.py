from datetime import datetime, date


def aktiv(start, slutt, tidspunkt):
	pass


def innenfor_dato(start, slutt, dato):
	pass


def formater_klokkeslett(dato_string):
	pass


def sorter_avtaler(avtaleliste):
	pass


if __name__ == '__main__':
	print("God luck!")




