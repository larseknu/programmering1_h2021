ut = 0;
for i in range(5):
	ut += i

print(ut)