for i in range(5):
	print(f"{i % 2}#")
