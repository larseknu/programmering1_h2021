a = 4
b = 5
if b >= a:
	print(b)
if a >= b:
	print(a)
else:
	print(b)