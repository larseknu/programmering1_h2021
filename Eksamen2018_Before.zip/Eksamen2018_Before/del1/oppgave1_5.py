arr = [1, 2, 3, 4, 5]
b = len(arr)
print(arr[b-1])
