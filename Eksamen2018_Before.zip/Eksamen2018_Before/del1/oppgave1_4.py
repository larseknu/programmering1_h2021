arr = [1, 2, 3, 4, 5]
print(arr[1])