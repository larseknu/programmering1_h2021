def circumference_rectangle(length, width):
    return 2 * length + 2 * width


print(circumference_rectangle(4, 5))
print(circumference_rectangle(109, 144))
