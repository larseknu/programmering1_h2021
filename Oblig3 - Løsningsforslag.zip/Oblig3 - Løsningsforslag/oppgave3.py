def print_list(list_to_print):
    for element in list_to_print:
        print(element)


animals = ['Lion', 'Honey badger', 'Quokka']

print_list(animals)
