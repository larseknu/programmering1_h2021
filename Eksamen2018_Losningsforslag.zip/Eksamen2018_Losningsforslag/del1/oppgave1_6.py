for i in range(5):
	print(i)


# Utskrift blir
# 0
# 1
# 2
# 3
# 4