for i in range(5):
	print(f"{i % 2}#")

# Utskrift blir:
# 0#
# 1#
# 0#
# 1#
# 0#