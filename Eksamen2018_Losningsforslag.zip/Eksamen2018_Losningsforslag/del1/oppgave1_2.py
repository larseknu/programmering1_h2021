a = 4
b = 5
if b >= a:
	print(b)
else:
	print(a)

# Utskrift blir
# 5
