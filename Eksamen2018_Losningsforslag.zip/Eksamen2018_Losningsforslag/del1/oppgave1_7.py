ut = 0;
for i in range(5):
	ut += i

print(ut)

# Utskrift blir:
# 10