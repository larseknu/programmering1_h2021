number1_str = input("Skriv inn et tall: ")
number2_str = input("Skriv inn et tall til: ")

number1 = float(number1_str)
number2 = float(number2_str)

print("*", number1 * number2)
print("/", number1 / number2)
print("+", number1 + number2)
print("-", number1 - number2)
print("%", number1 % number2)
print("**", number1 ** number2)
print("//", number1 // number2)