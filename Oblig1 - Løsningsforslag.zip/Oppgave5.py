person1 = 5
person2 = 9
person3 = 2.5
person4 = 21
person5 = 0

total_number = person1 + person2 + person3 + person4 + person5

print("Gjennomsnittlig antall småkaker spist: ", int(total_number / 5))