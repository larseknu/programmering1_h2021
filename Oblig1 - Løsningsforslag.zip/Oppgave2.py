firstname = "Ola"
lastname = "Nordmann"
age = 22

print(f'Hei, jeg heter {firstname} og er {lastname} år gammel')