a = 6
b = 3
c = 2

print(f"a={a}")
print(f"b={b}")
print(f"c={c}")
print(f"a + b * c = {a + b * c}")
print(f"(a + b) * c = {(a + b) * c}")
print(f"a / b / c = {a / b / c}")
print(f"a / (b / c) = {a / (b / c)}")