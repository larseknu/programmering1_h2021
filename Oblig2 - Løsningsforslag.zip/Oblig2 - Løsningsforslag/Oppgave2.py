print("Odd numbers from for-loop:")
for odd_number in range(9, 101, 2):
    print(odd_number)

print("\nOdd numbers from while-loop:")
odd_number = 9
while odd_number < 101:
    print(odd_number)
    odd_number += 2
